#!/bin/bash
mono MineEdit.exe
echo "I AM SO DAMN TIRED LET ME SLEEP FFFFFFFF"